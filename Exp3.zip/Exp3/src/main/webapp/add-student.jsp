<%@page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@page import="com.student.dao.StudentDAO"%>
<%@page import="com.student.model.Student"%>
<html>
<head>
    <title>Add Student</title>
</head>
<body>
    <h2>Add Student</h2>
    <form action="add-student.jsp" method="post">
        Roll No: <input type="text" name="rollNo"><br>
        Name: <input type="text" name="name"><br>
        Email: <input type="text" name="email"><br>
        Age: <input type="text" name="age"><br>
        <input type="submit" value="Add Student">
    </form>

    <%
        if (request.getMethod().equals("POST")) {
            int rollNo = Integer.parseInt(request.getParameter("rollNo"));
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            int age = Integer.parseInt(request.getParameter("age"));

            Student student = new Student(rollNo, name, email, age);
            StudentDAO dao = new StudentDAO();
            dao.addStudent(student);

            out.println("<p>Student added successfully!</p>");
        }
    %>
    <a href="index.jsp">Back to Home</a>
</body>
</html>
